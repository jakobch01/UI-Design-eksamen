import React from "react";

export default function TableRow({ cells = [], className = "" }) {
  return (
    <tr className={className}>
      {cells.map((cell, index) => (
        <td key={index} className="p-2 border-b border-gray-200">
          {cell}
        </td>
      ))}
    </tr>
  );
}
