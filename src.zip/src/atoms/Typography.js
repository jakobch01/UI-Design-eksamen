export function Heading({ children }) {
  return <h2 className="text-xl font-bold">{children}</h2>;
}